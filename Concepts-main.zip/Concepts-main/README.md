# Concepts
This Repo contains concepts and problems i have faced so far 
